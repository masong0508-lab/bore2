// BORE 2 (PlayStation) - shared types and world constants.
// The sequel to BORE (GBA): the voxel people, the rooms and the items are the real BORE data, now in true 3D.
#pragma once
#include <stdint.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <psxgpu.h>
#include <psxgte.h>
#include <psxpad.h>
#include <psxapi.h>
#include <psxetc.h>
// the SDK's GTE load macros read memory without telling the compiler: a fence first, so vertices written just before are really
// in memory when the GTE loads them (without it GCC may move the stores after the load: wrong, layout-dependent geometry)
#define GTE_FENCE() __asm__ volatile("" ::: "memory")
// the HUD's formatter (fmt.c): far quicker than the C library's
int bsprintf(char *o, const char *f, ...);
int bsnprintf(char *o, unsigned cap, const char *f, ...);
#define sprintf bsprintf
#define snprintf bsnprintf
#include <inline_c.h>
void boot(const char *stage);
void loading(const char *what, int pct);   // main.c: a loading screen with a bar, shown now (before a long job)   // main.c: prints a start-up stage on the screen (a trace for a hang)

typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32;

// 15-bit colour, the same bit layout the GBA used (red in the low bits): the BORE palettes port unchanged.
#define RGB(r,g,b) ((u16)((r)|((g)<<5)|((b)<<10)))
#define C_R(c) ((c)&31)
#define C_G(c) (((c)>>5)&31)
#define C_B(c) (((c)>>10)&31)
// 15-bit colour -> 8-bit channels for a primitive
#define R8(c) ((C_R(c)<<3)|(C_R(c)>>2))
#define G8(c) ((C_G(c)<<3)|(C_G(c)>>2))
#define B8(c) ((C_B(c)<<3)|(C_B(c)>>2))

#define SCREEN_W 320
#define SCREEN_H 240
#define CENTER_X (SCREEN_W/2)
#define CENTER_Y (SCREEN_H/2)

// ---- world units (y is DOWN, like the GTE: a height h sits at y = -h) ----
#define TILE   256      // one room tile
#define VOX    48       // one creature block (8 blocks = 384 = the height of a wall's doorway... a person is 1.5 tiles tall)
#define IUNIT  32       // one item unit (BORE items are 8 units per tile)
#define IZ     24       // one item z px (a 16 px crate is 384 tall, as tall as a person)
#define WALL_FULL 512   // a wall
#define WALL_LOW  160   // a low wall / a cut-away wall

// ---- the creature build space (BORE) ----
#define W 6
#define D 4
#define H 8

// ---- the map (BORE) ----
#define MW 80   // the map: the old 40x40 lots were one house; 80x80 holds the open-world city (a 5x5 grid of 16-tile blocks). 96x96 would not fit: see gfx.h
#define MH 80

#define CLAMP(v,lo,hi) ((v)<(lo)?(lo):(v)>(hi)?(hi):(v))
#define ABS(v) ((v)<0?-(v):(v))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

static inline int fx_mul(int a, int b) { return (int)(((long long)a * b) >> 12); }   // 20.12 x 20.12
#define COLD __attribute__((optimize("Os")))   // (code that runs now and then, not every frame: built small)
