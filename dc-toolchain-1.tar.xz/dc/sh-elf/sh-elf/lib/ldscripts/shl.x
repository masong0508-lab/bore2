/* Default linker script, for normal executables */
/* Copyright (C) 2014-2026 Free Software Foundation, Inc.
   Copying and distribution of this script, with or without modification,
   are permitted in any medium without royalty provided the copyright
   notice and this notice are preserved.  */
OUTPUT_FORMAT("coff-shl")
OUTPUT_ARCH(sh)
MEMORY
{
  ram : o = 0x1000, l = 512k
}
SECTIONS
{
  .text :
  {
    *(.text)
    *(.strings)
     _etext = . ;
  }
  .tors :
  {
    ___ctors = . ;
    *(.ctors)
    ___ctors_end = . ;
    ___dtors = . ;
    *(.dtors)
    ___dtors_end = . ;
  } > ram
  .data   ALIGN(0x1000) :
  {
    *(.data)
    *(.gcc_exc*)
    ___EH_FRAME_BEGIN__ = . ;
    *(.eh_fram*)
    ___EH_FRAME_END__ = . ;
    LONG(0);
     _edata = . ;
  }
  .bss  ALIGN(0x1000) :
  {
     _bss_start = . ;
    *(.bss)
    *(COMMON)
     _end = . ;
  }
  .stack :
  {
     _stack = . ;
    *(.stack)
  }
  .stab 0 (NOLOAD) :
  {
    *(.stab)
  }
  .stabstr 0 (NOLOAD) :
  {
    *(.stabstr)
  }
}
